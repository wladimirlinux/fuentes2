
<?php	

 require_once("conexion.php");
 ini_set('display_errors', 1);

if ($_FILES['archivo']["error"] > 0)

  {
  echo "Error: " . $_FILES['archivo']['error'] . "<br>";
  }
else
  {
  echo "Nombre: " . $_FILES['archivo']['name'] . "<br>";
  echo "Tipo: " . $_FILES['archivo']['type'] . "<br>";
  echo "Peso: " . ($_FILES["archivo"]["size"] / 1024) . " kB<br>";
  echo "Carpeta temporal: " . $_FILES['archivo']['tmp_name'];

  /*ahora con la funcion move_uploaded_file lo guardaremos en el destino que queramos*/

 move_uploaded_file($_FILES['archivo']['tmp_name'],"subidas/".$_FILES['archivo']['name']);

 echo "<br>";
 $fname =$_FILES['archivo']['name'];
 echo "Cargando nombre del archivo: ".$fname."<br>";

 $chk_ext = explode(".",$fname);


   if(strtolower(end($chk_ext)) == "csv")
         {
             //si es correcto, entonces damos permisos de lectura para subir
             $filename = "subidas/".$_FILES['archivo']['name'];
             $handle = fopen($filename, "r");
	     $sql = "DELETE from deudas";
	     mysql_query($sql) or die('Error: '.mysql_error());
 

             while (($data = fgetcsv($handle, 1000, ";")) !== FALSE)
             {
               //Insertamos los datos con los valores...

                $sql = "INSERT into deudas values('$data[0]','$data[1]','$data[2]')";
                mysql_query($sql) or die('Error: '.mysql_error());


             }
             //cerramos la lectura del archivo "abrir archivo" con un "cerrar archivo"
             fclose($handle);
	     
               $sql = "SELECT COUNT(`idcliente`) AS cantidad FROM deudas";
               $Result= mysql_query($sql) or die('Error: '.mysql_error());
               $dato = mysql_result($Result, 0);

             echo "<br>";
	     echo "<br>";
             echo "....:::: Carga masiva realizada con exito!. Se insertaron ".$dato." registros en la base de datos del IVR de cartera ::::....";
         }
         else
         {
            //si aparece esto es posible que el archivo no tenga el formato adecuado, inclusive cuando es cvs, revisarlo para             
//ver si esta separado por " , "
             echo "<br>";
	     echo "<br>";

             echo "Error: Archivo invalido!. Recuerde que debe guardar un archivo tipo CSV de excel de 3 columnas (Cedula cliente, cantidad de facturas pendientes, valor a pagar en letras)";
         }






 }


?>