
<?php  

 $link = mysqli_connect("localhost", "root", "tupass")  or die("Error: El servidor no puede conectar con la base de datos"); 
   if ($link){
   mysqli_select_db($link,"cartera");
   $tildes = $link->query("SET NAMES 'utf8'");
 }


 $query ="SELECT * FROM consultas";  
 $result = mysqli_query($link, $query);  



$libros = array();

while($row = mysqli_fetch_assoc($result)) 
{  

$libros[] = $row;      
}

if(isset($_POST["export_data"])) {
if(!empty($libros)) {
$filename = "libros.xls";
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=".$filename);
$mostrar_columnas = false;

foreach($libros as $libro) {
if(!$mostrar_columnas) {
echo implode("\t", array_keys($libro)) . "\n";
$mostrar_columnas = true;
}
echo implode("\t", array_values($libro)) . "\n";
}
}else{
echo "No hay datos a exportar";

}
exit;
}

 ?>  



 <!DOCTYPE html>  
 <html>  
      <head>  
           <title>Reporte de consultas a la base de datos</title>  
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.16/datatables.min.css"/>
<script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.16/datatables.min.js"></script>


          <script src="https://code.jquery.com/jquery-1.12.4.js"></script>  
          <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>  
          <script src="https://cdn.datatables.net/buttons/1.5.1/js/dataTables.buttons.min.js"></script> 
          <script src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.flash.min.js"></script> 
          <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script> 
          <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/pdfmake.min.js"></script> 
          <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/vfs_fonts.js"></script> 
      <script src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.html5.min.js"></script> 
 <script src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.print.min.js"></script> 



<script>
$(document).ready(function(){
$('#employee_data').DataTable();
});


 </script> 

          
          

 

      </head>  
      <body>  

<img src="imagenes/Banner.png" width="100%"/>

           <br /><br />  
<div class="container" align="center">


<div class="well-sm col-sm-12">

<div class="btn-group pull-center">

<form action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="post">

<button type="submit" id="export_data" name="export_data" value="Export to excel" class="btn btn-info">Exporte total registros a Excel</button>

</form>

</div>

</div>
           <div class="container">  
                <h3 align="center">Reporte de consultas realizadas en el IVR </h3>  
                <br />  
                <div class="table-responsive">  
                     <table id="employee_data" class="table table-striped table-bordered">  
                          <thead>  
                               <tr>  
                                    <td>Id</td>  
                                    <td>Fecha Consulta</td>  
                                    <td>Hora Consulta</td>  
                                    <td>Telefono del que llama</td>  
                                    <td>Resultado</td>
				    <td>Cedula</td>  
				    <td>Cuentas Vencidas</td>  
				    <td>Saldo Pendiente</td> 

                               </tr>  
                          </thead>  
                          <?php  
 $query ="SELECT * FROM consultas";  
 $result = mysqli_query($link, $query); 
			
                           while($row = mysqli_fetch_array($result)) 
                          {  




                               echo '  
                               <tr>  
                                    <td>'.$row["idconsultas"].'</td>  
                                    <td>'.$row["fechaConsulta"].'</td>  
                                    <td>'.$row["horaConsulta"].'</td>  
                                    <td>'.$row["telefono"].'</td>  
                                    <td>'.$row["resultado"].'</td>  
				    <td>'.$row["idcliente"].'</td>  
				    <td>'.$row["cuentasVencidas"].'</td>  
				    <td>'.$row["saldoPendiente"].'</td>  
                               </tr>  
                               ';  
                          }  

                          ?>  
                     </table>  
                </div>  
           </div>  

 </body> 
 </html>  

