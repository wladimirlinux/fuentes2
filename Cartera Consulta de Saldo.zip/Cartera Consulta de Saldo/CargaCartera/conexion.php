<?php	

$link = mysql_connect("localhost", "root", "tupass..") or die("Error: El servidor no puede conectar con la base de datos");

if ($link){
mysql_select_db("cartera", $link);

}

?>