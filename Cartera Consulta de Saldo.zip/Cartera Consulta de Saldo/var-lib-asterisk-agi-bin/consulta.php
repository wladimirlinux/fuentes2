#!/usr/bin/php -q

 /*
                                             ...::recursos::...
 $agi->exec('festival','"Por favor digite el numero de curso"'); //Aplicaci�n festival lee el texto
    $agi->exec('Playback','custom/NumCurso');
    $agi->exec('WaitExten',3);  //se podr�a aplicar un WaitExten.. cualquier aplicaci�n
    $result = $agi->get_data('beep'); //esta linea no funciona.
 */  $codigo = $result['result']; // cuando pueda capturarlo por dtmf


<?php

  set_time_limit(30);
  require("phpagi.php");
  include("conexion.php");
  error_reporting(E_ALL);

  $agi = new AGI();
  $agi->answer();
  $callerID= $agi->request[agi_callerid]; //Se utiliza para dejar el log de donde llaman
  $id = $_SERVER['argv'][1]; //Capturo el dato que viene del read de asterisk
  $sql='select * from deudas where idcliente='.$id;


  $result = mysql_query($sql,$link);
  $row= mysql_fetch_array($result);
	if($row['valor']){

	$agi->exec('festival','"La cantidad de facturas a pagar es "'.$row['cuentasVencidas'].'"."'); 
	$agi->exec('festival','"El valor total a pagar es de "'.'"'.$row['valor'].'"');

        $cuentasVencidas = $row['cuentasVencidas'];
        $saldoPendiente = $row['valor'];
        $resultado= "Exitoso"; 

        }

	else{
	     $agi->exec('festival','"No se encontraron facturas pendientes para esta cedula."');
	     $cuentasVencidas = "-";
	     $saldoPendiente = "-";
             $resultado= "Fallido";

	}

//dejo registro en la base de datos 


$hora = new DateTime("now", new DateTimeZone('America/Bogota'));
$fechaConsulta = $hora->format('Y-m-d');
$horaConsulta = $hora->format('H:i:s');

$sql="INSERT INTO `cartera`.`consultas` (`idconsultas`, `fechaConsulta`, `horaConsulta`, `telefono`, `resultado`, `idcliente`, `cuentasVencidas`, `saldoPendiente`) VALUES (NULL, "."'".$fechaConsulta."'".", "."'".$horaConsulta."'".","."'".$callerID."'".", "."'".$resultado."'".",  "."'".$id."'".",  "."'".$cuentasVencidas."'".",  "."'".$saldoPendiente."'".")";
$resultLog = mysql_query($sql,$link);



?>
