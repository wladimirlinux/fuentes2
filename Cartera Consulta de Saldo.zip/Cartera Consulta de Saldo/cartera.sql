-- phpMyAdmin SQL Dump
-- version 4.4.15.10
-- https://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 02-04-2018 a las 03:17:38
-- Versión del servidor: 5.5.56-MariaDB
-- Versión de PHP: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `cartera`
--
CREATE DATABASE IF NOT EXISTS `cartera` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `cartera`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `consultas`
--

CREATE TABLE IF NOT EXISTS `consultas` (
  `idconsultas` int(11) NOT NULL,
  `fechaConsulta` date NOT NULL,
  `horaConsulta` varchar(10) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `resultado` varchar(30) NOT NULL,
  `idcliente` varchar(20) NOT NULL,
  `cuentasVencidas` varchar(10) NOT NULL,
  `saldoPendiente` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `consultas`
--

INSERT INTO `consultas` (`idconsultas`, `fechaConsulta`, `horaConsulta`, `telefono`, `resultado`, `idcliente`, `cuentasVencidas`, `saldoPendiente`) VALUES
(1, '2018-04-01', '12:02', '2677673', 'Exitoso', '1020396396', '2', 'cuarenta mil trecientos pesos'),
(2, '2018-04-01', '12:02', '2677673', 'Exitoso', '1020396395', '2', 'cuarenta mil trecientos pesos'),
(3, '0000-00-00', '12:02', '2677673', 'Exitoso', '1020396395', '2', 'cuarenta mil trecientos pesos'),
(5, '0000-00-00', '12:02', '2677673', 'Exitoso', '1020396395', '2', 'cuarenta mil trecientos pesos'),
(20, '2018-04-01', '13:46:55', '1001', 'Exitoso', '2', 'Dos', 'sesenta y nuev mil cuatrocientos pesos'),
(21, '2018-04-01', '13:48:09', '1001', 'Fallido', '3456', '-', '-');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `deudas`
--

CREATE TABLE IF NOT EXISTS `deudas` (
  `idcliente` varchar(30) NOT NULL,
  `cuentasVencidas` varchar(15) NOT NULL,
  `valor` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `deudas`
--

INSERT INTO `deudas` (`idcliente`, `cuentasVencidas`, `valor`) VALUES
('1', 'Una', 'cuarenta mil pesos'),
('2', 'Dos', 'sesenta y nuev mil cuatrocientos pesos'),
('3', 'Una', 'treinta y nueve mil cuatrocientos pesos'),
('4', 'Dos', 'setenta y cinco mil doscientos cincuenta pesos'),
('5', 'Una', 'cuarenta mil pesos');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `consultas`
--
ALTER TABLE `consultas`
  ADD PRIMARY KEY (`idconsultas`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `consultas`
--
ALTER TABLE `consultas`
  MODIFY `idconsultas` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=22;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
